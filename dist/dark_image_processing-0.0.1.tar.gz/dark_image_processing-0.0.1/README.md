# package_name

Description. 
The package image_processing is used to:
	Processing:
		- Histrogram matching, Structural similarity and Resize Images
	Utils:
		- Read, Save and Plot Image	

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install dark_image_processing
```

## Author
Luis Ramires

## License
[MIT](https://choosealicense.com/licenses/mit/)